<#
Title: "SSH Key"
Author: "snychka"
Date: "08-23-2023"
Type: "Key"
Description: "Create an SSH Key for use inside of Windows" 
#>

# creates a key file from value passed in from tf
$DIRPATH = "C:\Users\Public\Desktop\LAB_FILES\"
$FILEPATH =  "$DIRPATH\lab-key"
new-item -ItemType Directory $DIRPATH
new-item -itemtype file $FILEPATH
$KeyContents = "${private_key}"
$KeyContents | Out-File -FilePath $FILEPATH -NoNewline -Encoding ascii

# allowing to work with non-default location for key file.
# use as ssh -i "C:\Users\Public\Desktop\LAB_FILES\lab-key" <user>@<host> <optional_command>
$User = New-Object System.Security.Principal.Ntaccount("PS-WIN-1\pslearner")
$ACL = Get-ACL $FilePath
$ACL.SetOwner($User)
$ACL | Set-Acl $FilePath
Icacls $FilePath /c /t /Grant PS-WIN-1\pslearner:F
Icacls $FilePath /c /t /Inheritance:d
Icacls $FilePath /c /t /Remove:g Administrator "Authenticated Users" BUILTIN\Administrators BUILTIN Everyone System Users INTERACTIVE