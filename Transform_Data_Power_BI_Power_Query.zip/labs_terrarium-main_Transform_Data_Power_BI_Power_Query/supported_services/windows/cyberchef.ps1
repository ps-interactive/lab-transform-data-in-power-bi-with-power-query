<#
Title: "CyberChef"
author: "treyescairo"
date: "09-28-2022"
type: "Cyber Operations Platform"
Description: "Install the latest version of CyberChef"
#>

<#
Find and download the latest version of CyberChef
Requires cred_init()
#>
$WebResponse = iwr -proxy $ProxyAddress -proxyCredential $proxy_credential -uri https://api.github.com/repos/gchq/CyberChef/releases/latest -UseBasicParsing
$iwrContent = ConvertFrom-Json $WebResponse.content
$csURI = $iwrContent.assets.browser_download_url
iwr -proxy $ProxyAddress -proxyCredential $proxy_credential -uri $csURI -outfile CyberChef.zip

<# Unzip the file and move it to its own directory #>
Expand-Archive -Path CyberChef.zip -DestinationPath C:\Users\pslearner\Desktop\CyberChef

<# Then instruct the learner to navigate to the HTML file and open it in locally in the Firefox browser. Internet Explorer will not work. #>