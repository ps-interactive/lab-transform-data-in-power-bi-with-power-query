<#
Title: "Ghidra"
Author: "treyescairo"
Date: "09-28-2022"
Type: "Decompiler"
Description: "Install the latest version of Ghidra"
#>

<#
NOTE: This entire install process can take an extra 10 minutes or so after the environment becomes available.
Make sure your learner has something else to do or is warned while it's getting set up. 
I've included the commands for the app_status function to help the learner see when things finish.
#>

<#
PREREQUISITES
Install JDK 11 by Adoptium
#>
app_status jdk11 "INITIALIZING"
app_status ghidra "INITIALIZING"
app_status jdk11 "IN PROGRESS"
choco install temurin11 -y --proxy=$ProxyAddress --proxy-user=$ProxyUser --proxy-password=$ProxyPassword
app_status jdk11 "DONE"

<#
INSTALL GHIDRA
Find and download the latest version of Ghidra
Requires cred_init()
#>
app_status ghidra "IN PROGRESS"
$WebResponse = iwr -proxy $ProxyAddress -proxyCredential $proxy_credential -uri https://api.github.com/repos/NationalSecurityAgency/ghidra/releases/latest -UseBasicParsing
$iwrContent = ConvertFrom-Json $WebResponse.content
$ghidraURI = $iwrContent.assets.browser_download_url
iwr -proxy $ProxyAddress -proxyCredential $proxy_credential -uri $ghidraURI -outfile ghidra.zip

<# Unzip the file and move it to its own directory #>
Expand-Archive -Path ghidra.zip -DestinationPath C:\Users\pslearner\Desktop\
app_status ghidra "DONE"

<# Then instruct the learner to navigate to the folder and run ghidraRun.bat. #>