<#
Title: "Ruby"
Author: "treyescairo"
Date: "9-27-2022"
Type: "Programming language"
Description: "Install Ruby"
#>

<# Requires chocolatey to be installed #>
choco install ruby -y --proxy=$ProxyAddress --proxy-user=$ProxyUser --proxy-password=$ProxyPassword