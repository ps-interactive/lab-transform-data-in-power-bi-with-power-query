<#
Title: "Strawberry Perl"
Author: "treyescairo"
Date: "9-27-2022"
Type: "Programming language"
Description: "Install Perl"
#>

<# Requires chocolatey to be installed #>
choco install strawberryperl -y --proxy=$ProxyAddress --proxy-user=$ProxyUser --proxy-password=$ProxyPassword