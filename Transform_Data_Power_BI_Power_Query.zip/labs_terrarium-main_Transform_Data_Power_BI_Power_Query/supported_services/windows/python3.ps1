<#
Title: "Python 3"
Author: "treyescairo"
Date: "9-27-2022"
Type: "Programming language"
Description: "Install Python 3"
#>

<# Requires chocolatey to be installed #>
choco install python3 --pre -y --proxy=$ProxyAddress --proxy-user=$ProxyUser --proxy-password=$ProxyPassword