<#
Title: "Burp Suite Community Edition"
Author: "treyescairo"
Date: "9-27-2022"
Type: "Web App Security Testing Platform"
Description: "Install Burp Suite Community Edition" 
#>

choco install burp-suite-free-edition -y --proxy=$ProxyAddress --proxy-user=$ProxyUser --proxy-password=$ProxyPassword