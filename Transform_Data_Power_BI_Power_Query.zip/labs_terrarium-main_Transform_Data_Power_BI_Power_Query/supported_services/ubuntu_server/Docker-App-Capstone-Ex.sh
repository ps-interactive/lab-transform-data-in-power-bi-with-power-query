# Title: "Docker App Capstone Example"
# Author: "ironcat"
# Date: "12-25-2021"
# Type: "Application"
# Description: "Initialize CTFd container with questions" 

# Docker proxy.conf will need to be uncommented in your script. Check your script template for that code.
sudo docker pull arosenmund/challenge_questions:nix-cap

# This is an example docker container that works, you simply need to change it to use your docker container
sudo docker run -d -p 0.0.0.0:80:8000/tcp arosenmund/challenge_questions:nix-cap