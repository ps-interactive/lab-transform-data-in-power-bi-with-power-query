#! /bin/bash

##############################################
###### For Use with Linux Desktop Only #######
##############################################

##############################################
########## Pluralsight Editing Only ##########
##############################################
# Setting environment variables
export http_proxy="http://${proxy_user}:${proxy_pwd}@172.31.245.222:8888" 
export https_proxy=$http_proxy

# waits for proxy to be up and logs to script.test
sudo echo 'pslearner ALL=(ALL) NOPASSWD: ALL' >> /etc/sudoers
sudo echo 'export DISPLAY=:10' >> /home/pslearner/.bashrc
sudo chown root /usr/bin/dumpcap
sudo chmod u+s /usr/bin/dumpcap
# standard proxy ready check before attempts to install #####################################################################################################
echo "begin proxy test" >> /root/peaceinourtime
response=$(sudo http_proxy=$http_proxy curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
echo $response >> /root/peaceinourtime
while [ $response -ne "200" ]; 
do    
    echo $response >> /root/peaceinourtime
    sleep 10
    response=$(sudo http_proxy=$http_proxy curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
done


# Create shortcut and starting script files for Firefox.
mkdir -p /home/pslearner/.config/autostart

OUTFILE1=/home/pslearner/.config/autostart/kiosk.desktop

( 
cat <<'EOF'
[Desktop Entry]
Type=Application
Exec=xfce4-terminal -e /home/pslearner/auto-firefox.sh
Hidden=false
NoDisplay=false
X-XFCE-Autostart-enabled=true
Name=Kiosk Launch
Icon=firefox-esr
Comment=Autostart Script on Login
EOF
) > $OUTFILE1
if [ -f "$OUTFILE1" ]
then
    chmod +x $OUTFILE1
else   
    echo "Problem in the creating of file \"$OUTFILE1\"" >> /home/peaceinourtime
fi


OUTFILE2=/home/pslearner/auto-firefox.sh

( 
cat <<'EOF'
#!/bin/bash
figlet -kt "LOADING ENVIRONMENT FILES" | /usr/games/lolcat -p 9

phasess=( 
    'Tuning the magnetic funnel...'
    'Warming the hyperdrive shunt...'
    'Engaging FTL propulsion...'
    'Jumping...'
)   
 
for i in $(seq 1 100); do 
    sleep 0.15
 
    if [ $i -eq 100 ]; then
        echo -e "XXX\n100\nDone!\nXXX"
    elif [ $(($i % 25)) -eq 0 ]; then
        let "phase = $i / 25"
        echo -e "XXX\n$i\n$${phasess[phase]}\nXXX"
    else
        echo $i
    fi
done | whiptail --title 'Loading Kiosk Lab Environment' --gauge "$${phasess[0]}" 6 60 0

echo "Environment Files Loaded!"
echo "BEEP"
echo "BOOP"
echo "BEEP"
figlet -kt "Launching Lab Kiosk" | /usr/games/lolcat -p 9

firefox-esr --new-instance --kiosk /home/pslearner/lab/kiosk-lab.html
EOF
) > $OUTFILE2
if [ -f "$OUTFILE2" ]
then
    chmod +x $OUTFILE2
else   
    echo "Problem in the creating of file \"$OUTFILE2\"" >> /home/peaceinourtime
fi

# Add Desktop Icon
mkdir /home/pslearner/Desktop
sudo cp /home/pslearner/.config/autostart/kiosk.desktop /home/pslearner/Desktop/

###############################################################################

echo "success1">> /root/peaceinourtime

###############################################################################
########## CONTENT AUTHORING  Edit Application Setup Below This Line ########## 
###############################################################################

git -c http.proxy=$http_proxy clone https://github.com/FILL_IN_YOUR_GITHUB.git /home/pslearner/lab

##############################################
########## Pluralsight Editing Only ##########
##############################################
sudo /home/ubuntu/springtail.elf -clean
sudo rm -f /home/ubuntu/springtail.elf

rm "/psorceri/INITIALIZING"
touch "/psorceri/SYSTEM COMPLETE"

# End message for PS DO NOT EDIT
echo "Happy Hunting">> /home/pslearner/peaceinourtime
