# Title: "CyberChef"
# Author: "treyescairo, mlloyddavies"
# Date: "09-28-2022"
# Type: "Cyber Operations Platform"
# Description: "Install the latest version of CyberChef"

# NOTE: This is only meant for use on U20D, not U18C.

# Find and download the latest version of CyberChef
sudo curl --proxy $http_proxy -s https://api.github.com/repos/gchq/CyberChef/releases/latest | grep "browser_download_url.*zip" | cut -d : -f 2,3 | tr -d \" | sudo https_proxy=$http_proxy wget -i -

# Unzip the file and move it to its own directory
sudo find ./CyberChef*.zip -exec unzip -d ./CyberChef '{}' +

# Then instruct the learner to navigate to the HTML file and open it in locally in a browser or use the following to create a shortcut.
directory="/CyberChef"
html_file=$(find "$directory" -maxdepth 1 -type f -name "*.html" | head -n 1)
desktop_file="/home/pslearner/Desktop/CyberChef.desktop"

touch $desktop_file

cat <<EOF > "$desktop_file"
[Desktop Entry]
Version=1.0
Type=Application
Name=CyberChef
Exec=xdg-open "$html_file"
Icon=web-browser
Terminal=false
EOF

sudo chmod +x /home/pslearner/Desktop/CyberChef.desktop
sudo chown pslearner:pslearner /home/pslearner/Desktop/CyberChef.desktop