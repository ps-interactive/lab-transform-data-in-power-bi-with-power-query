# Title: "TMUX"
# Author: "treyescairo"
# Date: "09-29-2022"
# Type: "Terminal Multiplexer"
# Description: "Configure TMUX"

# NOTE: TMUX is installed on U18C and U20D by default, but isn't configured beyond default This script is to remedy and customize that.

# Exporting the Lab Title for tmux.conf to use.
echo "export LABTITLE=\"INSERT LAB NAME HERE\"" | sudo tee -a /etc/bash.bashrc

# tmux.conf one-liner for setting the style
echo "set-option -g status-style fg=colour15,bg=colour61; set-option -g status-left-length 100; set-option -g status-left \"\$LABTITLE \"; set-option -g status-right \"#H %H:%M %d-%b-%Y\"; set-option -g status-right-length 50; set-window-option -g window-status-current-format \"[#S #P:#{pane_current_command}]\"; set-window-option -g window-status-style fg=colour15,bg=colour61; set-window-option -g pane-border-style fg=black,bg=black; set-window-option -g pane-active-border-style fg=colour61,bg=colour61" | sudo tee -a /etc/tmux.conf

# Enable TMUX for every bash session
# NOTE: If you configure this setting for U20D, it will interfere with using tabs in terminal. Every tabbed session will open up the last session of TMUX. So, it's most helpful for U18C disconnects.
echo "if [ ! \$TMUX ]; then session=\$(tmux ls | grep \"pslab\"); if [ -z \"\$session\" ]; then tmux new -s pslab; else tmux a -t pslab; fi; fi" | sudo tee -a /etc/bash.bashrc