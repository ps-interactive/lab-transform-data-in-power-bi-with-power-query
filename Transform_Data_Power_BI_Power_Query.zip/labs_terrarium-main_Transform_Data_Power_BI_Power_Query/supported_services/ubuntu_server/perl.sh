# Title: "Perl"
# Author: "treyescairo"
# Date: "9-27-2022"
# Type: "Programming language"
# Description: "Install Perl"

sudo http_proxy=$http_proxy apt install -y perl