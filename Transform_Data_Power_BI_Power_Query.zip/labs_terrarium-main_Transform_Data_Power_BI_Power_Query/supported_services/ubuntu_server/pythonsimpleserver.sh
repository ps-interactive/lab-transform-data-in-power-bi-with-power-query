# Title: "Python Simple Server"
# Author: "ironcat"
# Date: "12-25-2021"
# Type: "Vulnerable Application"
# Description: "Install OWASP Juice Shop - a vulnerable web application" 

##########################################################################################################
# A few things to note:
# The instance you're attaching this to needs to be set as a t2.medium instance type, else you risk the docker container crashing.
# Make sure that the ingress/egress ports have been opened in the security group settings.
# Make sure you have assigned a private_ip address to the instance as well. This IP address will be used in any web browsing or scans you attempt.
# For more information about Juice Shop, visit: https://owasp.org/www-project-juice-shop/
##########################################################################################################

# PREREQUISITES
sudo http_proxy=$http_proxy apt update
sudo http_proxy=$http_proxy apt install -y python3.7

# PYTHON SIMPLE SERVER

# This line is less required than illustrative. Just wanted to have a web directory made to point to.
# You can point the server at something you've pulled down from GitHub or had the learner create. Whatever your flavor!
mkdir ./www

# Start the server in the target directory on port 80.
sudo python3.7 -m http.server --directory ./www 80