# Title: "Apache Server"
# Author: "treyescairo"
# Date: "9-27-2022"
# Type: "Server"
# Description: "Install Apache and have it use a specific directory"

##########################################################################################################
# A few things to note:
# The instance you're attaching this to probably would benefit from being set as a medium instance type. It may not be necessary depending on how resource intensive your site is. 
# Make sure that the ingress/egress ports have been opened in the security group settings.
# Make sure you have assigned a private_ip address to the instance as well. This IP address will be used in any web browsing or scans you attempt.
# Make sure all website files are hosted in the /var/www/html folder.
# For more information about Apache Server, visit: https://httpd.apache.org/docs/
##########################################################################################################

# Install Apache
sudo http_proxy=$http_proxy apt install -y apache2