# Title: "OWASP Juice Shop"
# Author: "ironcat"
# Date: "12-25-2021"
# Type: "Vulnerable Web Application"
# Description: "Install OWASP Juice Shop - a vulnerable web application" 

##########################################################################################################
# A few things to note:
# The instance you're attaching this to needs to be set as a medium instance type, else you risk the docker container crashing.
# Make sure that the ingress/egress ports have been opened in the security group settings.
# Make sure you have assigned a private_ip address to the instance as well. This IP address will be used in any web browsing or scans you attempt.
# For more information about Juice Shop, visit: https://owasp.org/www-project-juice-shop/
##########################################################################################################

# Docker proxy.conf will need to be uncommented in your script. Check your script template for that code.
sudo docker pull bkimminich/juice-shop

# This will start the contianer and redirect normal port 80 traffic to port 3000 in the container, which is what the Juice Shop is set up on.
sudo docker run -d -p 80:3000 bkimminich/juice-shop
