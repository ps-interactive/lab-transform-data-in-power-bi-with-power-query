# Title: "Wordpress Vulnerability 1"
# Author: "ironcat"
# Date: "12-25-2021"
# Type: "Vulnerable Web Application"
# Description: "Install Wordpress - a vulnerable web application" 

# Installs current apache on ubuntu
sudo http_proxy= $http_proxy apt update
sudo http_proxy= $http_proxy apt -y install ec2-instance-connect
sudo http_proxy= $http_proxy DEBIAN_FRONTEND=noninteractive apt -y --force-yes install wordpress php libapache2-mod-php mysql-server php-mysql

# add site file to /etc/apache2/sites-available.conf

echo "<VirtualHost *:80>
    ServerAdmin webmaster@site-name.com
    ServerName wordpress
    DocumentRoot /usr/share/wordpress
    ErrorLog /var/log/apache2/error.log
    CustomLog /var/log/apache2/access.log combined
<Directory /usr/share/wordpress>
    Options FollowSymLinks
    AllowOverride Limit Options FileInfo
    DirectoryIndex index.php
    Order allow,deny
    Allow from all
</Directory>
<Directory /usr/share/wordpress/wp-content>
    Options FollowSymLinks
    Order allow,deny
    Allow from all
</Directory> 
</VirtualHost>" >> /home/ubuntu/wordpress.conf

sudo mv /home/ubuntu/wordpress.conf /etc/apache2/sites-available/wordpress.conf

# enable site, and rewrite module

sudo a2ensite wordpress
sudo a2enmod rewrite
sudo a2dissite 000-default
# restart apache to enable changes
sudo systemctl reload apache2

#Wordpress MySQL config

sudo mysql -e "CREATE DATABASE wordpress;"
sudo mysql -e "GRANT ALL ON wordpress.* TO 'wordpress'@'localhost' IDENTIFIED BY 'wordpress';"
sudo mysql mysql -e "FLUSH PRIVILEGES;"

#echo this into a file /etc/wordpress/config-localhost.php
echo "<?php
define('DB_NAME', 'wordpress');
define('DB_USER', 'wordpress');
define('DB_PASSWORD', 'wordpress');
define('DB_HOST', 'localhost');
define('DB_COLLATE', 'utf8_general_ci');
define('WP_CONTENT_DIR', '/usr/share/wordpress/wp-content');
?>" >> /home/ubuntu/config-localhost.php

sudo mv /home/ubuntu/config-localhost.php /etc/wordpress/config-localhost.php

# Restart mysql
sudo service mysql start

# Need wp-cli
curl --proxy  $http_proxy -O https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar
chmod +x wp-cli.phar
sudo mv wp-cli.phar /usr/local/bin/wp

# Now need to install to get past the initial page.
# Install WordPress.
#Configure wordpress

# add configuration file link for default configuration
sudo ln -s /etc/wordpress/config-localhost.php /etc/wordpress/config-default.php



sudo chown www-data:www-data -R /usr/share/wordpress

wp core install --title="Damn Vulnerable WordPress" --admin_user="admin" --admin_password="admin" --admin_email="admin@example.com" --url="http://172.31.37.55/" --skip-email --path="/usr/share/wordpress" --allow-root
sudo chown -R www-data:www-data /usr/share/wordpress
#sudo chmod -R 755 /usr/share/wordpress
sudo systemctl reload apache2
sudo systemctl restart mysql
# one more step to actually publish the site!


sudo http_proxy= $http_proxy wp plugin update --all --path="/usr/share/wordpress" --allow-root
sudo http_proxy= $http_proxy wp plugin activate --all
#sudo http_proxy= $http_proxy theme update twentyseventeen #--path="/usr/share/wordpress" --allow-root
#sudo http_proxy= $http_proxy wp theme install twentysixteen #--activate --path="/usr/share/wordpress" --allow-root

