# Title: "OpenPLC and ScadaLTS"
# Author: "mlloyddavies"
# Date: "06-27-2024"
# Type: "OT System with One PLC and Scada with HMI and data historian"
# Description: "Creates containers for OpenPLC, ScadaLTS and a data historian (database)" 

##########################################################################################################
# A few things to note:
# This script will create an OpenPLC container, a ScadaLTS container and a database container. If you only want an OpenPLC container, use the ot_plc.sh script
# Make sure that the ingress/egress ports have been opened in the security group settings.
# You will need to provide a PLC program in structured text (.st) format for OpenPLC and an HMI configuration file (.zip|.json) for ScadaLTS
# You will also need to provide any required physics simulations files. 
# OpenPLC default credentials: openplc:openplc
# ScadaLTS default credentials: 
# Database credentials: root:root
# For more information about OpenPLC, visit https://autonomylogic.com/
# For more information about ScadaLTS, visit http://scada-lts.com/
##########################################################################################################

# Docker proxy.conf will need to be uncommented in your script. Check your script template for that code.
sudo git -c http.proxy=$http_proxy clone https://github.com/ps-interactive/ot-plc-scada.git

# This will start all 3 contianers. 
# The PLC will be accessible on 172.18.0.2:8000. Modbus communciation is over port 502.
# The HMI will be accessible on 172.18.0.3:8080.
sudo docker-compose -f  /ot-plc-scada/docker-compose.yml up
