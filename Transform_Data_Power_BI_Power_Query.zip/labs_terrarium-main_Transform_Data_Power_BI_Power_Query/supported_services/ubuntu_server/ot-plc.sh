# Title: "OpenPLC and ScadaLTS"
# Author: "mlloyddavies"
# Date: "06-27-2024"
# Type: "OT System with One PLC"
# Description: "Creates container running OpenPLC" 

##########################################################################################################
# A few things to note:
# This script will create an OpenPLC container. If you also want an HMI and data historian, use the ot_plc_scada.sh script
# Make sure that the ingress/egress ports have been opened in the security group settings.
# You will need to provide a PLC program in structured text (.st) format for OpenPLC.
# OpenPLC default credentials: openplc:openplc
# For more information about OpenPLC, visit https://autonomylogic.com/
##########################################################################################################

# Docker proxy.conf will need to be uncommented in your script. Check your script template for that code.
sudo git -c http.proxy=$http_proxy clone https://github.com/ps-interactive/ot-plc.git

# This will start the contianer. The PLC will be accessible on 172.18.0.2:8000. Modbus communciation is over port 502.
sudo docker-compose -f  /ot-plc/docker-compose.yml up