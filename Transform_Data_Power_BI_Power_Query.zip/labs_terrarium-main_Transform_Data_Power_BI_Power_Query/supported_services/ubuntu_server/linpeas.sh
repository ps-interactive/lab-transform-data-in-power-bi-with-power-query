# Title: "linPEAS Script"
# Author: "treyescairo"
# Date: "09-26-2022"
# Type: "Privilege Escalation"
# Description: "Download the latest linPEAS script from Github"

sudo https_proxy=$http_proxy wget https://github.com/carlospolop/PEASS-ng/releases/latest/download/linpeas.sh
sudo chmod +x ./linpeas.sh

# Then just have the learner run ./linpeas.sh from the console.