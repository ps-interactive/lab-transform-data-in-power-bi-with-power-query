# Title: "PoshC2"
# Author: "treyescairo"
# Date: "09-21-2022"
# Type: "C2 Framework"
# Description: "Install the latest PoshC2 framework"

###################################################################################################################
# A few things to note:
# You will need to make sure that your ports are appropriately opened.
# Make sure that the ingress/egress ports have been opened in the security group settings.
# Make sure you have assigned a private_ip address to victim instances as well.
# For more information about PoshC2, visit: https://github.com/nettitude/PoshC2
###################################################################################################################

# This is the text from the install-for-docker.sh script found at the repo listed above. It has been edited down for simplicity of installation.

# Install PoshC2
# A POSIX variable
OPTIND=1         # Reset in case getopts has been used previously in the shell.

# Initialize our own variables:
GIT_BRANCH="master"

# [+] Installing PoshC2 for Docker for branch \"$GIT_BRANCH\"
# [+] Installing scripts to /usr/local/bin
rm -f /usr/local/bin/_posh-common
rm -f /usr/local/bin/fpc
rm -f /usr/local/bin/posh
rm -f /usr/local/bin/posh-server
rm -f /usr/local/bin/posh-config
rm -f /usr/local/bin/posh-log
rm -f /usr/local/bin/posh-service
rm -f /usr/local/bin/posh-stop-service
rm -f /usr/local/bin/posh-project
rm -f /usr/local/bin/posh-docker-clean
rm -f /usr/local/bin/posh-stop-server
rm -f /usr/local/bin/posh-docker-debug
rm -f /usr/local/bin/sharpsocks
sudo curl --proxy $http_proxy https://raw.githubusercontent.com/nettitude/PoshC2/$GIT_BRANCH/resources/scripts/_posh-common -o /usr/local/bin/_posh-common >/dev/null
sudo curl --proxy $http_proxy https://raw.githubusercontent.com/nettitude/PoshC2/$GIT_BRANCH/resources/scripts/fpc -o /usr/local/bin/fpc >/dev/null
sudo curl --proxy $http_proxy https://raw.githubusercontent.com/nettitude/PoshC2/$GIT_BRANCH/resources/scripts/posh-docker -o /usr/local/bin/posh >/dev/null
sudo curl --proxy $http_proxy https://raw.githubusercontent.com/nettitude/PoshC2/$GIT_BRANCH/resources/scripts/posh-docker-server -o /usr/local/bin/posh-server >/dev/null
sudo curl --proxy $http_proxy https://raw.githubusercontent.com/nettitude/PoshC2/$GIT_BRANCH/resources/scripts/posh-config -o /usr/local/bin/posh-config >/dev/null
sudo curl --proxy $http_proxy https://raw.githubusercontent.com/nettitude/PoshC2/$GIT_BRANCH/resources/scripts/posh-log -o /usr/local/bin/posh-log >/dev/null
sudo curl --proxy $http_proxy https://raw.githubusercontent.com/nettitude/PoshC2/$GIT_BRANCH/resources/scripts/posh-service -o /usr/local/bin/posh-service >/dev/null
sudo curl --proxy $http_proxy https://raw.githubusercontent.com/nettitude/PoshC2/$GIT_BRANCH/resources/scripts/posh-stop-service -o /usr/local/bin/posh-stop-service >/dev/null
sudo curl --proxy $http_proxy https://raw.githubusercontent.com/nettitude/PoshC2/$GIT_BRANCH/resources/scripts/posh-project -o /usr/local/bin/posh-project >/dev/null
sudo curl --proxy $http_proxy https://raw.githubusercontent.com/nettitude/PoshC2/$GIT_BRANCH/resources/scripts/posh-docker-clean -o /usr/local/bin/posh-docker-clean >/dev/null
sudo curl --proxy $http_proxy https://raw.githubusercontent.com/nettitude/PoshC2/$GIT_BRANCH/resources/scripts/posh-docker-stop-server -o /usr/local/bin/posh-stop-server >/dev/null
sudo curl --proxy $http_proxy https://raw.githubusercontent.com/nettitude/PoshC2/$GIT_BRANCH/resources/scripts/posh-docker-debug -o /usr/local/bin/posh-docker-debug >/dev/null
sudo curl --proxy $http_proxy https://raw.githubusercontent.com/nettitude/PoshC2/$GIT_BRANCH/resources/scripts/sharpsocks-docker -o /usr/local/bin/sharpsocks >/dev/null
chmod +x /usr/local/bin/fpc
chmod +x /usr/local/bin/posh
chmod +x /usr/local/bin/posh-server
chmod +x /usr/local/bin/posh-config
chmod +x /usr/local/bin/posh-log
chmod +x /usr/local/bin/posh-service
chmod +x /usr/local/bin/posh-stop-service
chmod +x /usr/local/bin/posh-project
chmod +x /usr/local/bin/posh-docker-clean
chmod +x /usr/local/bin/posh-stop-server
chmod +x /usr/local/bin/posh-docker-debug
chmod +x /usr/local/bin/posh-docker-debug
chmod +x /usr/local/bin/sharpsocks

POSH_PROJECTS_DIR="/var/poshc2"
mkdir -p $POSH_PROJECTS_DIR
sudo curl --proxy $http_proxy https://raw.githubusercontent.com/nettitude/PoshC2/$GIT_BRANCH/resources/config-template.yml -o "$POSH_PROJECTS_DIR/config-template.yml" >/dev/null

