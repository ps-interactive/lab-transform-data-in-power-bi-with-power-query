# Title: "PowerShell Empire"
# Author: "treyescairo"
# Date: "09-21-2022"
# Type: "C2 Framework"
# Description: "Install the latest Empire C2 framework"

###################################################################################################################
# A few things to note:
# You will need to make sure that your ingress/egress ports are appropriately opened in the security group settings for the server that is running.
# The commands for running the server and running the client needs to be in different windows. See the TMUX command as an option to handle this best.
# Make sure you have assigned a private_ip address to victim instances as well.
# For more information about PS Empire, visit: https://bc-security.gitbook.io/empire-wiki/quickstart/installation
###################################################################################################################

# Pull version 4.10 of the image. Version 5.0 seems to have some issues still.
docker pull bcsecurity/empire:v4.10.0

# Run the server with the rest api and socket ports open
docker run -dit -p 1337:1337 -p 5000:5000 bcsecurity/empire:v4.10.0

# To run the client against the already running server container
docker container ls
docker exec -it {container-id} ./ps-empire client

# If you'd like to use the Starkiller GUI on Ubuntu Desktop, run the following commands.

wget 'https://github.com/BC-SECURITY/Starkiller/releases/download/v1.10.0/starkiller-1.10.0.AppImage' -e use_proxy=on -e https_proxy=$http_proxy -O /home/pslearner/starkiller

sudo chmod +x /home/pslearner/starkiller

# Then have the learner execute the starkiller.AppImage from the home folder to launch the GUI. Credentials are empireadmin:password123.