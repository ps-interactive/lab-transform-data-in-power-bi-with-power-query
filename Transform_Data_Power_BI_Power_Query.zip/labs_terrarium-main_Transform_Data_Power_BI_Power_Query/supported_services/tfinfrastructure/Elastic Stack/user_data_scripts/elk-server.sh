#! /bin/bash

##############################################
########## Pluralsight Editing Only ##########
##############################################
# Setting environment variables
export http_proxy="http://${proxy_user}:${proxy_pwd}@172.31.245.222:8888" 
export https_proxy=$http_proxy

# Exporting the Lab Title for tmux.conf to use.
echo "export LABTITLE=\"PLURALSIGHT LABS\"" | sudo tee -a /etc/bash.bashrc

# tmux.conf one-liner for setting the style
echo "set-option -g status-style fg=colour15,bg=colour61; set-option -g status-left-length 100; set-option -g status-left \"\$LABTITLE \"; set-option -g status-right \"#H %H:%M %d-%b-%Y\"; set-option -g status-right-length 50; set-window-option -g window-status-current-format \"[#S #P:#{pane_current_command}]\"; set-window-option -g window-status-style fg=colour15,bg=colour61; set-window-option -g pane-border-style fg=black,bg=black; set-window-option -g pane-active-border-style fg=colour61,bg=colour61" | sudo tee -a /etc/tmux.conf

# Enable TMUX for every bash session
echo "if [ ! \$TMUX ]; then session=\$(tmux ls | grep \"pslab\"); if [ -z \"\$session\" ]; then tmux new -s pslab; else tmux a -t pslab; fi; fi" | sudo tee -a /etc/bash.bashrc

# timesyncd attempts to reach out to ntp.ubuntu.com but hangs because it gets not response, this will speed up overall loadtime.
systemctl stop systemd-timesyncd
systemctl disable systemd-timesyncd

# Test for valid proxy before running the rest of the code
echo "begin proxy test" >> /root/peaceinourtime
response=$(sudo http_proxy=$http_proxy curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
echo $response >> /root/peaceinourtime
while [ $response -ne "200" ]; 
do    
    echo $response >> /root/peaceinourtime
    sleep 10
    response=$(sudo http_proxy=$http_proxy curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
done

# Reboot Framework Start
rcount_file="/rcount" # path and file to store reboot count
[ -f $rcount_file ]
rcheck=$?
if [ $rcheck -ne 0 ]; then # if $rcount_file does not yet exist
    echo "0" > $rcount_file
fi

# Checks the value of the $rcount_file and returns the value.
rcount_check () {
    rcount=$(cat $rcount_file)
    return $rcount
}

# Increments the $rcount_file contents by 1. Use this before causing a reboot. 
rcount_inc () {
    rcount=$(cat $rcount_file)
    ((rcount++))
    echo "$rcount" > $rcount_file
}

# Add succcessful proxy execution message to peaceinourtime log
echo "success1">> /psorceri/peaceinourtime

###############################################################################
########## CONTENT AUTHORING  Edit Application Setup Below This Line ########## 
###############################################################################

##############################################
########## END CONTENT AUTHORING #############
##############################################

##############################################
########## Pluralsight Editing Only ##########
##############################################
sudo /home/ubuntu/springtail.elf -clean
sudo rm -f /home/ubuntu/springtail.elf

rm "/psorceri/INITIALIZING"
touch "/psorceri/SYSTEM COMPLETE"

# End message for PS DO NOT EDIT
echo "Happy Hunting">> /home/pslearner/peaceinourtime