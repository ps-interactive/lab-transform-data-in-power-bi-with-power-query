#! /bin/bash

##############################################
########## Pluralsight Editing Only ##########
##############################################
# Setting environment variables
export http_proxy="http://${proxy_user}:${proxy_pwd}@172.31.245.222:8888" 
export https_proxy=$http_proxy

# Exporting the Lab Title for tmux.conf to use.
echo "export LABTITLE=\"PLURALSIGHT LABS\"" | sudo tee -a /etc/bash.bashrc

# tmux.conf one-liner for setting the style
echo "set-option -g status-style fg=colour15,bg=colour61; set-option -g status-left-length 100; set-option -g status-left \"\$LABTITLE \"; set-option -g status-right \"#H %H:%M %d-%b-%Y\"; set-option -g status-right-length 50; set-window-option -g window-status-current-format \"[#S #P:#{pane_current_command}]\"; set-window-option -g window-status-style fg=colour15,bg=colour61; set-window-option -g pane-border-style fg=black,bg=black; set-window-option -g pane-active-border-style fg=colour61,bg=colour61" | sudo tee -a /etc/tmux.conf

# Enable TMUX for every bash session
# NOTE: If you configure this setting for U20D, it will interfere with using tabs in terminal. Every tabbed session will open up the last session of TMUX. So, it's most helpful for U18C disconnects.
# echo "if [ ! \$TMUX ]; then session=\$(tmux ls | grep \"pslab\"); if [ -z \"\$session\" ]; then tmux new -s pslab; else tmux a -t pslab; fi; fi" | sudo tee -a /etc/bash.bashrc

# waits for proxy to be up and logs to script.test
sudo echo 'pslearner ALL=(ALL) NOPASSWD: ALL' >> /etc/sudoers
sudo echo 'export DISPLAY=:10' >> /home/pslearner/.bashrc
sudo chown root /usr/bin/dumpcap
sudo chmod u+s /usr/bin/dumpcap
# standard proxy ready check before attempts to install #####################################################################################################
echo "begin proxy test" >> /root/peaceinourtime
response=$(sudo http_proxy=$http_proxy curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
echo $response >> /root/peaceinourtime
while [ $response -ne "200" ]; 
do    
    echo $response >> /root/peaceinourtime
    sleep 10
    response=$(sudo http_proxy=$http_proxy curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
done

# Reboot Framework Start
rcount_file="/rcount" # path and file to store reboot count
[ -f $rcount_file ]
rcheck=$?
if [ $rcheck -ne 0 ]; then # if $rcount_file does not yet exist
    echo "0" > $rcount_file
fi

# Checks the value of the $rcount_file and returns the value.
rcount_check () {
    rcount=$(cat $rcount_file)
    return $rcount
}

# Increments the $rcount_file contents by 1. Use this before causing a reboot. 
rcount_inc () {
    rcount=$(cat $rcount_file)
    ((rcount++))
    echo "$rcount" > $rcount_file
}

# Add succcessful proxy execution message to peaceinourtime log
echo "success1">> /psorceri/peaceinourtime

###############################################################################
########## CONTENT AUTHORING  Edit Application Setup Below This Line ########## 
###############################################################################

# Start with checking reboot count.
rcount_check; r=$?
if [ $r -eq 0 ]; then
    # FIRST BOOT CYCLE STARTS HERE

    # Establishing App load tracking
    mkdir /psorceri
    echo "alias status='ls -ls /psorceri |cut -d \" \" -f 10,11,12,13,14'" >> /home/pslearner/.bashrc
    touch "/psorceri/INITIALIZING"

    ########################################
    # k8s
    # loosely based on
    # https://www.cloudsigma.com/how-to-install-and-use-kubernetes-on-ubuntu-20-04/

    # nope, not consistent, use cloud init yaml instead
    # sudo hostnamectl set-hostname control-plane
    # runuser -u pslearner -c 'xauth add \"$(hostname)/unix:10\" MIT-MAGIC-COOKIE-1 $(xauth list | cut -d \" \" -f5)'

    sudo systemctl stop apparmor
    sudo systemctl disable apparmor

    sudo http_proxy="$http_proxy" https_proxy="$http_proxy" curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.29/deb/Release.key | sudo gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg
    sudo echo 'deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v1.29/deb/ /' | sudo tee /etc/apt/sources.list.d/kubernetes.list
    sudo http_proxy="$http_proxy" apt-get update
    sudo http_proxy="$http_proxy" apt-get install -y kubelet=1.29.0-1.1 kubeadm=1.29.0-1.1 kubectl=1.29.0-1.1 kubernetes-cni=1.3.0-1.1

    sudo swapoff -a
    sudo modprobe br_netfilter
    sudo sysctl net.bridge.bridge-nf-call-iptables=1
cat <<EOF | sudo tee /etc/docker/daemon.json
{ "exec-opts": ["native.cgroupdriver=systemd"],
"log-driver": "json-file",
"log-opts":
{ "max-size": "100m" },
"storage-driver": "overlay2"
}
EOF
    sudo systemctl enable docker
    sudo systemctl daemon-reload
    sudo systemctl restart docker

    sudo systemctl set-environment HTTPS_PROXY="$http_proxy"
    sudo systemctl set-environment HTTP_PROXY="$http_proxy"
    # https://github.com/kubernetes/kubeadm/issues/2767#issuecomment-1344620047
    # sudo systemctl set-environment NO_PROXY="localhost,127.0.0.1,::1,172.31.24.31"
    sudo systemctl set-environment NO_PROXY="localhost,127.0.0.1,::1,$(hostname -i | cut -d ' ' -f 1)"
    sudo mkdir /etc/containerd
cat << EOF > config.toml
version = 2
[plugins."io.containerd.grpc.v1.cri".containerd.runtimes.runc]
  runtime_type = "io.containerd.runc.v2"
  [plugins."io.containerd.grpc.v1.cri".containerd.runtimes.runc.options]
    SystemdCgroup = true
EOF
    sudo mv config.toml /etc/containerd/ # gymnastics 'cause can't sudo > ... could use tee, instead
    sudo systemctl restart containerd.service

    sudo kubeadm config images pull --kubernetes-version=v1.29.0
    sudo kubeadm init --pod-network-cidr=10.244.0.0/16 --kubernetes-version=v1.29.0

    sudo mkdir /home/pslearner/.kube
    sudo cp -i /etc/kubernetes/admin.conf /home/pslearner/.kube/config
    sudo chown -R pslearner:pslearner /home/pslearner/.kube

    git -c http.proxy=$http_proxy clone https://github.com/flannel-io/flannel.git /home/pslearner/flannel
    pushd .
    cd /home/pslearner/flannel
    sudo git checkout tags/v0.25.3
    popd
    sudo mkdir /run/flannel
cat <<EOF | sudo tee /run/flannel/subnet.env
FLANNEL_NETWORK=10.244.0.0/16
FLANNEL_SUBNET=10.244.0.1/24
FLANNEL_MTU=8951
FLANNEL_IPMASQ=true
EOF
    # repetition maybe not needed, but trying to replicate exactly what worked when last 2 commands were done manually
    sudo kubectl --kubeconfig="/home/pslearner/.kube/config" apply -f /home/pslearner/flannel/Documentation/kube-flannel.yml
    sudo kubectl --kubeconfig="/home/pslearner/.kube/config" apply -f /home/pslearner/flannel/Documentation/k8s-old-manifests/kube-flannel-rbac.yml
    sudo kubectl --kubeconfig="/home/pslearner/.kube/config" taint nodes control-plane node-role.kubernetes.io/control-plane:NoSchedule-
    sudo kubectl --kubeconfig="/home/pslearner/.kube/config" apply -f /home/pslearner/flannel/Documentation/kube-flannel.yml

    # sample of pulling down an image for k8s
    # sudo crictl pull gcr.io/k8s-minikube/kubernetes-bootcamp:v1

    sleep 60 # hacky, delays clean-up so installation can complete

# end of k8s
########################################


    # Example Usage for App Load Tracking
    # touch "/psorceri/NMAP INITIALIZING"
    # mv "/psorceri/NMAP INITIALIZING" "/psorceri/NMAP IN PROGRESS"

    # Pull git repo for lab if your lab has lab files a repo will need to be created and the file uploaded under a "LAB_FILES"  folder to end up here:
    # git -c http.proxy=$http_proxy clone https://github.com/ps-interactive/lab_apache-commons-text-enumeration-detection.git /home/pslearner/lab

    #! SOME APPS need https proxy like so 'sudo https_proxy=$https_proxy'
    #########################################################################################################
    # Install additionally required software packages
    # Repo install - Ubuntu
    # Example1 - sudo http_proxy=$http_proxy apt install -y apache2
    # Example2 - Bypassing Acknowledgement Requirements - sudo http_proxy=$http_proxy DEBIAN_FRONTEND=noninteractive apt -y --force-yes install mysql-server
    #
    #########################################################################################################
    # # Curl package and install from binary
    # # Example - 
    # sudo curl --proxy $https_proxy https://raw.githubusercontent.com/rapid7/metasploit-omnibus/master/config/templates/metasploit-framework-wrappers/msfupdate.erb >> /home/pslearner/msfinstall 2>errors
    # sudo chmod 755 /home/pslearner/msfinstall
    # sudo http_proxy=$http_proxy /home/pslearner/msfinstall
    #
    ##########################################################################################################
    # # Use Docker or Docker Compose
    # 
    #   sudo mkdir -p /etc/systemd/system/docker.service.d
    #   sudo touch /etc/systemd/system/docker.service.d/proxy.conf
    #   echo "[Service]" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
    #   echo "Environment=\"http_proxy=$http_proxy\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
    #   echo "Environment=\"https_proxy=$http_proxy\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
    #   echo "Environment=\"NO_PROXY=localhost,127.0.0.1,::1\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
    #   echo '{"live-restore":true}' | sudo tee -a /etc/docker/daemon.json
    #   sudo systemctl daemon-reload
    #   sudo systemctl restart docker

    # # docker commands now work "docker pull" etc.
    # sudo docker pull bkimminich/juice-shop

    # # docker compose project from github
    # COURSE_DIR_PATH=/home/pslearner/os-analysis-with-wazuh
    # git -c http.proxy=$http_proxy clone https://github.com/ps-interactive/lab_os_anlaysis_wazuh.git $COURSE_DIR_PATH
    # # Update permissions because user data script runs as root
    # chown -R pslearner:pslearner $COURSE_DIR_PATH
    # cd $COURSE_DIR_PATH
    # sudo docker-compose up -d &

    # # Uncomment the line below to start the Attack Application service found on http://localhost:28657
    # sudo systemctl start attack-application.service

    # # END FIRST BOOT CYCLE. START SECOND BOOT CYCLE.
    # rcount_inc
    # sudo reboot
    # elif [ $r -eq 1 ]; then

    # # END SECOND BOOT CYCLE. START THIRD BOOT CYCLE.
    # rcount_inc
    # sudo reboot
    # elif [ $r -eq 2 ]; then

    ##############################################
    ########## END CONTENT AUTHORING #############
    ##############################################

    ##############################################
    ########## Pluralsight Editing Only ##########
    ##############################################
    sudo /home/ubuntu/springtail.elf -clean
    sudo rm -f /home/ubuntu/springtail.elf
    sudo systemctl unset-environment HTTP_PROXY
    sudo systemctl unset-environment HTTPS_PROXY
    sudo systemctl restart containerd.service

    rm "/psorceri/INITIALIZING"
    touch "/psorceri/SYSTEM COMPLETE"

    # End message for PS DO NOT EDIT
    echo "Happy Hunting">> /home/pslearner/peaceinourtime
fi