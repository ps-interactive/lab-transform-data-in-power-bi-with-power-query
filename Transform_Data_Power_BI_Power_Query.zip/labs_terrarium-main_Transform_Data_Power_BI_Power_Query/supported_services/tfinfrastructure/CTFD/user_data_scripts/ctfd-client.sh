#! /bin/bash

##############################################
########## Pluralsight Editing Only ##########
##############################################
# Setting environment variables
export http_proxy="http://${proxy_user}:${proxy_pwd}@172.31.245.222:8888" 
export https_proxy=$http_proxy

# Exporting the Lab Title for tmux.conf to use.
echo "export LABTITLE=\"PLURALSIGHT LABS\"" | sudo tee -a /etc/bash.bashrc

# tmux.conf one-liner for setting the style
echo "set-option -g status-style fg=colour15,bg=colour61; set-option -g status-left-length 100; set-option -g status-left \"\$LABTITLE \"; set-option -g status-right \"#H %H:%M %d-%b-%Y\"; set-option -g status-right-length 50; set-window-option -g window-status-current-format \"[#S #P:#{pane_current_command}]\"; set-window-option -g window-status-style fg=colour15,bg=colour61; set-window-option -g pane-border-style fg=black,bg=black; set-window-option -g pane-active-border-style fg=colour61,bg=colour61" | sudo tee -a /etc/tmux.conf

# Enable TMUX for every bash session
# NOTE: If you configure this setting for U20D, it will interfere with using tabs in terminal. Every tabbed session will open up the last session of TMUX. So, it's most helpful for U18C disconnects.
# echo "if [ ! \$TMUX ]; then session=\$(tmux ls | grep \"pslab\"); if [ -z \"\$session\" ]; then tmux new -s pslab; else tmux a -t pslab; fi; fi" | sudo tee -a /etc/bash.bashrc

# waits for proxy to be up and logs to script.test
sudo echo 'pslearner ALL=(ALL) NOPASSWD: ALL' >> /etc/sudoers
sudo echo 'export DISPLAY=:10' >> /home/pslearner/.bashrc
sudo chown root /usr/bin/dumpcap
sudo chmod u+s /usr/bin/dumpcap
# standard proxy ready check before attempts to install #####################################################################################################
echo "begin proxy test" >> /root/peaceinourtime
response=$(sudo http_proxy=$http_proxy curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
echo $response >> /root/peaceinourtime
while [ $response -ne "200" ]; 
do    
    echo $response >> /root/peaceinourtime
    sleep 10
    response=$(sudo http_proxy=$http_proxy curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
done

# Reboot Framework Start
rcount_file="/rcount" # path and file to store reboot count
[ -f $rcount_file ]
rcheck=$?
if [ $rcheck -ne 0 ]; then # if $rcount_file does not yet exist
    echo "0" > $rcount_file
fi

# Checks the value of the $rcount_file and returns the value.
rcount_check () {
    rcount=$(cat $rcount_file)
    return $rcount
}

# Increments the $rcount_file contents by 1. Use this before causing a reboot. 
rcount_inc () {
    rcount=$(cat $rcount_file)
    ((rcount++))
    echo "$rcount" > $rcount_file
}

# Add succcessful proxy execution message to peaceinourtime log
echo "success1">> /psorceri/peaceinourtime

###############################################################################
########## CONTENT AUTHORING  Edit Application Setup Below This Line ########## 
###############################################################################

# Establishing App load tracking
mkdir /psorceri
echo "alias status='ls -ls /psorceri |cut -d \" \" -f 10,11,12,13,14'" >> /home/pslearner/.bashrc
touch "/psorceri/INITIALIZING"

# Copy lab files to learner's desktop
git -c http.proxy=$http_proxy clone -b net-proto-capstone-v2 https://github.com/ps-interactive/labs_net_proto_capstone.git /home/pslearner/Desktop/LAB_FILES
sudo rm /home/pslearner/Desktop/LAB_FILES/ctfd.db
sudo rm /home/pslearner/Desktop/LAB_FILES/README.md
sudo chown -R pslearner: /home/pslearner/Desktop/LAB_FILES/

## Create Shortcut for CTFd
sudo echo "[Desktop Entry]" >> /home/pslearner/Desktop/challenge.desktop
sudo echo "Type=Application" >> /home/pslearner/Desktop/challenge.desktop
sudo echo "Terminal=false" >> /home/pslearner/Desktop/challenge.desktop
sudo echo "Name=Challenge Questions" >> /home/pslearner/Desktop/challenge.desktop
sudo echo "Icon=firefox-esr" >> /home/pslearner/Desktop/challenge.desktop
sudo echo "Exec=firefox-esr --new-window http://172.31.24.142/" >> /home/pslearner/Desktop/challenge.desktop
sudo echo "Categories=Application" >> /home/pslearner/Desktop/challenge.desktop
sudo chown pslearner: /home/pslearner/Desktop/challenge.desktop
sudo chmod +x /home/pslearner/Desktop/challenge.desktop

## Create Shorcut for Wireshark
sudo echo "[Desktop Entry]" >> /home/pslearner/Desktop/wireshark.desktop
sudo echo "Type=Application" >> /home/pslearner/Desktop/wireshark.desktop
sudo echo "Terminal=false" >> /home/pslearner/Desktop/wireshark.desktop
sudo echo "Name=Wireshark" >> /home/pslearner/Desktop/wireshark.desktop
sudo echo "Icon=org.wireshark.Wireshark" >> /home/pslearner/Desktop/wireshark.desktop
sudo echo "Exec=/usr/bin/wireshark" >> /home/pslearner/Desktop/wireshark.desktop
sudo echo "Categories=Application" >> /home/pslearner/Desktop/wireshark.desktop
sudo chown pslearner: /home/pslearner/Desktop/wireshark.desktop
sudo chmod +x /home/pslearner/Desktop/wireshark.desktop

# Create Autostart for Challenge Questions
mkdir -p /home/pslearner/.config/autostart

sudo cp /home/pslearner/Desktop/challenge.desktop /home/pslearner/.config/autostart/challenge.desktop

## Set firefox as default application for .pdf files - Requires the pslearner context
sudo runuser -l pslearner -c 'xdg-mime default firefox-esr.desktop application/pdf'

echo -e ${win_rdp_password} >> /home/pslearner/sudo_password

# Example Usage for App Load Tracking
# touch "/psorceri/NMAP INITIALIZING"
# mv "/psorceri/NMAP INITIALIZING" "/psorceri/NMAP IN PROGRESS"

# Pull git repo for lab if your lab has lab files a repo will need to be created and the file uploaded under a "LAB_FILES"  folder to end up here:
# git -c http.proxy=$http_proxy clone https://github.com/ps-interactive/lab_apache-commons-text-enumeration-detection.git /home/pslearner/lab

#! SOME APPS need https proxy like so 'sudo https_proxy=$HTTPS_PROXY'
#########################################################################################################
# Install additionally required software packages
# Repo install - Ubuntu
# Example1 - sudo http_proxy=$http_proxy apt install -y apache2
# Example2 - Bypassing Acknowledgement Requirements - sudo http_proxy=$http_proxy DEBIAN_FRONTEND=noninteractive apt -y --force-yes install mysql-server
#
#########################################################################################################
# # Curl package and install from binary
# # Example - 
# sudo curl --proxy $HTTPS_PROXY https://raw.githubusercontent.com/rapid7/metasploit-omnibus/master/config/templates/metasploit-framework-wrappers/msfupdate.erb >> /home/pslearner/msfinstall 2>errors
# sudo chmod 755 /home/pslearner/msfinstall
# sudo http_proxy=$http_proxy /home/pslearner/msfinstall
#
##########################################################################################################
# # Use Docker or Docker Compose
# 
#   sudo mkdir -p /etc/systemd/system/docker.service.d
#   sudo touch /etc/systemd/system/docker.service.d/proxy.conf
#   echo "[Service]" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
#   echo "Environment=\"http_proxy=$http_proxy\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
#   echo "Environment=\"https_proxy=$http_proxy\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
#   echo "Environment=\"NO_PROXY=localhost,127.0.0.1,::1\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
#   echo '{"live-restore":true}' | sudo tee -a /etc/docker/daemon.json
#   sudo systemctl daemon-reload
#   sudo systemctl restart docker

# # docker commands now work "docker pull" etc.
# sudo docker pull bkimminich/juice-shop

# # docker compose project from github
# COURSE_DIR_PATH=/home/pslearner/os-analysis-with-wazuh
# git -c http.proxy=$http_proxy clone https://github.com/ps-interactive/lab_os_anlaysis_wazuh.git $COURSE_DIR_PATH
# # Update permissions because user data script runs as root
# chown -R pslearner:pslearner $COURSE_DIR_PATH
# cd $COURSE_DIR_PATH
# sudo docker-compose up -d &

# # Uncomment the line below to start the Attack Application service found on http://localhost:28657
# sudo systemctl start attack-application.service

##############################################
########## END CONTENT AUTHORING #############
##############################################

##############################################
########## Pluralsight Editing Only ##########
##############################################
sudo /home/ubuntu/springtail.elf -clean
sudo rm -f /home/ubuntu/springtail.elf

rm "/psorceri/INITIALIZING"
touch "/psorceri/SYSTEM COMPLETE"

# End message for PS DO NOT EDIT
echo "Happy Hunting">> /home/pslearner/peaceinourtime
