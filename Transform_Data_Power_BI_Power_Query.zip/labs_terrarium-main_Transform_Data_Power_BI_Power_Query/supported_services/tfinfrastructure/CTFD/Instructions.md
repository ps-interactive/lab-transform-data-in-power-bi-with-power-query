# Instructions
Custom build for labs that would like to use the CTFD environment


## Creating Questions
On your local machine, run the following commands to start the CTFD Docker container:

`sudo docker pull arosenmund/pssec-ctfd:latest`

`sudo docker run -p 80:8000 arosenmund/pssec-ctfd:latest  -it -d`

With the container up and running, browse to http://localhost

Login with the following credentials:

> un: psorcerer
> pw: pssecislife

Click the the "Admin Panel" tab on the top of the page.

Then click the "Challenges" tab.

Create challenges by clicking the "+" beside the word challenges and following the instructions. Make sure they are not "hidden" and view them as the learner would prior to moving on.

Once complete, copy the SQLite database out of the running container.
```
docker cp <container>:/opt/CTFd/CTFd/ctfd.db .
```
Then upload the ctfd.db to the GitHub repository associated with the lab to pull down the question files into the environment.
  
In the ctfd-server.sh bash script, run:
```
sudo docker cp /home/pslearner/LAB_FILES/ctfd.db ctfd:/opt/CTFd/CTFd/ctfd.db
```
And subsequently change the permissions for the file:

```
sudo docker exec -u root ctfd chown ctfd: /opt/CTFd/CTFd/ctfd.db
```

That's it!

## Authoring Instructions for the Learner

On the given CTFD Client desktop that is used the learner will have a link that takes them to `http://172.31.24.142`.