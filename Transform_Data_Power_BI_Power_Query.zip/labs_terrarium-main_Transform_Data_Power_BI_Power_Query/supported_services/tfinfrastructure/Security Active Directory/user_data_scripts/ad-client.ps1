<powershell>
<# Pluralsight Editing Only #>

<# Setting environment variables for this script #>
$HTTP_Proxy="http://${proxy_user}:${proxy_pwd}@172.31.245.222:8888" 
$ProxyAddress="http://172.31.245.222:8888"
$ProxyPassword="${proxy_pwd}"
$ProxyUser="${proxy_user}"

<# REBOOT FRAMEWORKS START #>
<# Checks if this is first boot, and sets $rcount to 0. #>
$rcheck = test-path c:\rcount
if ($rcheck -eq $False) 
{
    $rcount = 0
    $rcount | out-file c:\rcount
}
<# Checks the value of the c:\rcount file and returns the value. #>
function rcount_check()
{
    $rcount = get-content c:\rcount
    return $rcount
}

<# Increments the rcount file contents by 1. Use this before causing a reboot. #>

function rcount_inc()
{
    [int]$rcount = get-content c:\rcount
    $rcount++
    $rcount | out-file c:\rcount
}
<# REBOOT FRAMEWORK END #>

<# 
Credential functions include required credentials for guacamole function, net.webrequest proxy use and global local credental as Administrator with new PW.
All globally usable varaiables created, need to run again after a reboot.
#>
function cred_init()
{
    net user Administrator ${win_rdp_password}
    $global:message2 = "${win_rdp_password}"; $message2 |out-file -append c:/peaceinourtime.txt
    $global:message3 = "Local Administator Account PW : " + $message2
    <# Establish Proxy Credentials #>
    $global:puser = $ProxyUser
    $global:ppass = $ProxyPassword
    $global:psecpasswd = ConvertTo-SecureString $ppass -AsPlainText -Force
    $global:proxy_credential = New-Object System.Management.Automation.PSCredential($puser, $psecpasswd)
    [system.net.webrequest]::DefaultWebProxy = new-object system.net.webproxy($ProxyAddress)
    $global:webclient = New-Object System.Net.webclient
    $global:webclient.Proxy.Credentials = $proxy_credential
    <# Establish local system credentials #>
    $global:luser = "Administrator"
    $global:lpass = "${win_rdp_password}"
    $global:lsecpasswd = ConvertTo-SecureString $lpass -AsPlainText -Force
    $global:local_credential = New-Object System.Management.Automation.PSCredential($luser, $lsecpasswd)
    $global:local_credential
}

function remove_amznicons() {
    remove-item "c:\Users\Public\Desktop\EC2 Microsoft Windows Guide.website"
    remove-item "c:\Users\Public\Desktop\EC2 Feedback.website"
}

function clone_labgit ($gituri) {
    refreshenv
    <# 
    Always follow using "LAB_FILE" folder to then hold all conent the lab or this will fail
    Example - clone_labgit  "https://github.com/ps-interactive/lab_visualizing_network_traffic_wireshark.git"
    #>
    $gituri
    $gitstub = $gituri.split("/")[4].split(".")[0]
    $gitstub >> c:\peaceinourtime.txt
    $gitpath1 = 'c:\Users\Public\Desktop\'+$gitstub
    $gitpath1 >> c:\peaceinourtime.txt
    <# These variables can be used if you would like to specifically pull out a single folder from the GitHub Repo and pull that down. Replace $gitpath1 with $gitpath2 in the later copy-item command. #>
    # $gitfolder = '\FOLDERNAME\'
    $gitpath2 = 'C:\Users\Public\Desktop\'+$gitstub+$gitfolder
    $gitpath2 >> c:\peaceinourtime.txt
    
    $gitlist = "-c http.proxy=$HTTP_PROXY clone $gituri $gitpath1"
    try {start-process  -filepath 'C:\Program Files\git\bin\git.exe' -argumentlist $gitlist -wait -ErrorAction continue}catch{$_ >> c:\peaceinourtime.txt }
    
    <# These commands are for taking the GitHub folder and turning it into a "LAB_FILES" folder on the desktop for a more uniform look across labs. #>
    copy-item -recurse $gitpath1 -destination 'c:\Users\Public\Desktop\LAB_FILES\'
    remove-item -recurse -force $gitpath1
}
function create_dskticon ($TargetFile,$ShortcutFile) {
    #$TargetFile = "C:\Program Files\Wireshark\Wireshark.exe"
    #$ShortcutFile = "C:\Users\Public\Desktop\Wireshark.lnk"
    $WScriptShell = New-Object -ComObject WScript.Shell
    $Shortcut = $WScriptShell.CreateShortcut($ShortcutFile)
    $Shortcut.TargetPath = $TargetFile
    $Shortcut.IconLocation = "$TargetFile, 0"
    $Shortcut.Save()
}

<# Function to create app status updates for the status of software being installed. #>
$function = 'powershell -noexit -exec bypass -command "$stats = import-clixml -path C:\ProgramData\init_status.xml;$stats| out-gridview"'
out-file -InputObject $function -filepath 'C:\Users\Public\Desktop\STATUS.bat' -NoNewline -Encoding Ascii    

function app_status ($application_name,$update_status){
    $path = "C:\ProgramData\init_status.xml"
    $file = get-childitem "C:\ProgramData\init_status.xml" -ErrorAction SilentlyContinue
    if($file){
        $status_table = import-clixml $path
        $new_test = $status_table |?{$_.Application -eq "$application_name"}
            if ($new_test){
                                         $app_update = $status_table |?{$_.Application -eq "$application_name"}
                                         $app_update.Status = $update_status
                                         Export-Clixml -InputObject $status_table -Path $path                         
                                        }
                                        else{
                                                $arguments = @{
                                                            Application = $application_name
                                                            Status = $update_status
                                                            }
                                                            $new_status_table = @()           
                                                            $new_status_table+= $status_table 
                                                            $table = [pscustomobject]$arguments
                                                            $new_status_table+= [pscustomobject]$arguments
                                                            Export-Clixml -InputObject $new_status_table -Path $path  
                                                            }
        out-file -InputObject $output -Append -FilePath ./Initialization_Status.txt
    }
        else{
            $arguments = @{
                Application = $application_name
                Status = $update_status
            }
            $table = [pscustomobject]$arguments
            Export-Clixml -InputObject $table -Path $path
            }
    }

<#  Start with checking reboot count. #>
$r = rcount_check
if ($r -eq 0)
{

<# FIRST BOOT CYCLE STARTS HERE #>
cred_init
$Global:message3 |out-file c:\Users\Public\Desktop\Lab_Info.txt -append
Disable-ieESC
remove_amznicons

<# CONTENT AUTHORING  Edit Application Setup Below This Line #>

<# Set up permanent environment variables for every PowerShell session. #>
# New-Item -ItemType file C:\Windows\System32\WindowsPowerShell\v1.0\Profile.ps1
# Add-Content C:\Windows\System32\WindowsPowerShell\v1.0\Profile.ps1 '$example1 = "This is Example 1."'
# Add-Content C:\Windows\System32\WindowsPowerShell\v1.0\Profile.ps1 '$example2 = "This is Example 2."'

<# AUTHOR APPLICATION INSTALLATIONS METHODS #>

<# Chocolatey Install Example #>
# choco install pwsh -y --proxy=$ProxyAddress --proxy-user=$ProxyUser --proxy-password=$ProxyPassword

<# GitHub Clone Example #>
# clone_labgit "https://github.com/ps-interactive/lab_visualizing_network_traffic_wireshark.git"

<# Invoke Web Request Download Example #>
# invoke-webrequest -uri <downloaduri> -usebasicparsing -outfile <filename>;start-process <filename> (there are few variations that may be required for starting new processes)

<# Install Windows Feature Example #>
# Example - Get-WindowsFeature -Name *RSAT* | Install-windowsfeature

<# App Status Example #>
# app_status powershell "INITIALIZING"
# (Use Application Installation Here)
# app_status powershell "DONE"
<# Place STATUS.bat on Desktop for Reviewing App Status #>
# start-process c:\Users\Public\Desktop\STATUS.bat
<# Set DNS for Active Directory DC#>
Set-DnsClientServerAddress -InterfaceAlias "Ethernet 3" -ServerAddresses ("172.31.24.110","172.31.24.1")
Set-DnsClient -InterfaceAlias "Ethernet 3" -ConnectionSpecificSuffix "globomantics.co"
Set-DnsClientGlobalSetting -SuffixSearchList @("globomantics.co")

rcount_inc

<# Add computer to DC #>
$user = "globomantics\psadmin"
$pass = "P@ssW0rD!"
$adminPass = ConvertTo-SecureString $pass -AsPlainText -Force
$Credential = New-Object System.Management.Automation.PSCredential ($user, $adminPass)

Add-Computer -ComputerName CLIENT01 -DomainName globomantics.co -Credential $Credential -Restart -Force

Restart-Computer -Force

<# END FIRST BOOT CYCLE. START SECOND BOOT CYCLE #>

} elseif ($r -eq 1) { 
cred_init

"Restart successful."| out-file c:/peaceinourtime.txt -append;
Add-LocalGroupMember -Group "Remote Desktop Users" -Member "globomantics\Domain Users"

<# END SECOND BOOT CYCLE. START THIRD BOOT CYCLE #>
# rcount_inc
# Restart-Computer -Force
# } elseif ($r -eq 2) {
# cred_init

<# END CONTENT AUTHORING #>

<# Pluralsight Editing Only. This must be in the last boot cycle. #>

Start-Process -FilePath "C:\springtail.exe" -ArgumentList "-clean" -Wait
Remove-Item -Path "C:\springtail.exe" -Force

$message = "iambecomedeath"; $message | out-file c:/peaceinourtime.txt -append;
}

</powershell>
<# Optional persist tag will run the script at each restart. #>
<persist>true</persist>





