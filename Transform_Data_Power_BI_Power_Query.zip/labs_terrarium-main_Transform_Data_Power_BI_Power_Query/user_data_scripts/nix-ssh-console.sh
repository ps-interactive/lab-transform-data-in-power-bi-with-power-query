#! /bin/bash

##############################################
########## Pluralsight Editing Only ##########
##############################################
# Setting environment variables
export http_proxy="http://${proxy_user}:${proxy_pwd}@172.31.245.222:8888" 
export https_proxy=$http_proxy

# For assistance when converting older labs to Terrarium v4.3.
# export HTTP_PROXY=$http_proxy
# export HTTPS_PROXY=$http_proxy

# Exporting the Lab Title for tmux.conf to use.
echo "export LABTITLE=\"PLURALSIGHT LABS\"" | sudo tee -a /etc/bash.bashrc

# tmux.conf one-liner for setting the style
echo "set-option -g status-style fg=colour15,bg=colour61; set-option -g status-left-length 100; set-option -g status-left \"\$LABTITLE \"; set-option -g status-right \"#H %H:%M %d-%b-%Y\"; set-option -g status-right-length 50; set-window-option -g window-status-current-format \"[#S #P:#{pane_current_command}]\"; set-window-option -g window-status-style fg=colour15,bg=colour61; set-window-option -g pane-border-style fg=black,bg=black; set-window-option -g pane-active-border-style fg=colour61,bg=colour61" | sudo tee -a /etc/tmux.conf

# Enable TMUX for every bash session
echo "if [ ! \$TMUX ]; then session=\$(tmux ls | grep \"pslab\"); if [ -z \"\$session\" ]; then tmux new -s pslab; else tmux a -t pslab; fi; fi" | sudo tee -a /etc/bash.bashrc

# timesyncd attempts to reach out to ntp.ubuntu.com but hangs because it gets not response, this will speed up overall loadtime.
systemctl stop systemd-timesyncd
systemctl disable systemd-timesyncd

# Test for valid proxy before running the rest of the code
echo "begin proxy test" >> /root/peaceinourtime
response=$(sudo http_proxy=$http_proxy curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
echo $response >> /root/peaceinourtime
while [ $response -ne "200" ]; 
do    
    echo $response >> /root/peaceinourtime
    sleep 10
    response=$(sudo http_proxy=$http_proxy curl --silent --write-out '%%{http_code}' --output /dev/null www.google.com)
done

# Reboot Framework Start
rcount_file="/rcount" # path and file to store reboot count
[ -f $rcount_file ]
rcheck=$?
if [ $rcheck -ne 0 ]; then # if $rcount_file does not yet exist
    echo "0" > $rcount_file
fi

# Checks the value of the $rcount_file and returns the value.
rcount_check () {
    rcount=$(cat $rcount_file)
    return $rcount
}

# Increments the $rcount_file contents by 1. Use this before causing a reboot. 
rcount_inc () {
    rcount=$(cat $rcount_file)
    ((rcount++))
    echo "$rcount" > $rcount_file
}

# Add succcessful proxy execution message to peaceinourtime log
echo "success1">> /psorceri/peaceinourtime

###############################################################################
########## CONTENT AUTHORING  Edit Application Setup Below This Line ########## 
###############################################################################

# Start with checking reboot count.
rcount_check; r=$?
if [ $r -eq 0 ]; then
    # FIRST BOOT CYCLE STARTS HERE

    # Establishing App load tracking
    mkdir /psorceri
    echo "alias status='ls -ls /psorceri |cut -d \" \" -f 10,11,12,13,14'" >> /home/pslearner/.bashrc
    touch "/psorceri/INITIALIZING"

    # Example Usage for App Load Tracking
    # touch "/psorceri/NMAP INITIALIZING"
    # mv "/psorceri/NMAP INITIALIZING" "/psorceri/NMAP IN PROGRESS"

    # Pull git repo for lab if your lab has lab files a repo will need to be created and the file uploaded under a "LAB_FILES"  folder to end up here:
    # git -c http.proxy=$http_proxy clone https://github.com/ps-interactive/lab_apache-commons-text-enumeration-detection.git /home/pslearner/lab

    #! SOME APPS need https proxy like so 'sudo https_proxy=$https_proxy'
    #########################################################################################################
    # Install additionally required software packages
    # Repo install - Ubuntu
    # Example1 - sudo http_proxy=$http_proxy apt install -y apache2
    # Example2 - Bypassing Acknowledgement Requirements - sudo http_proxy=$http_proxy DEBIAN_FRONTEND=noninteractive apt -y --force-yes install mysql-server
    #
    #########################################################################################################
    # # Curl package and install from binary
    # # Example - 
    # sudo curl --proxy $https_proxy https://raw.githubusercontent.com/rapid7/metasploit-omnibus/master/config/templates/metasploit-framework-wrappers/msfupdate.erb >> /home/pslearner/msfinstall 2>errors
    # sudo chmod 755 /home/pslearner/msfinstall
    # sudo http_proxy=$http_proxy /home/pslearner/msfinstall
    #
    ##########################################################################################################
    # # Use Docker or Docker Compose
    # 
    #   sudo mkdir -p /etc/systemd/system/docker.service.d
    #   sudo touch /etc/systemd/system/docker.service.d/proxy.conf
    #   echo "[Service]" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
    #   echo "Environment=\"http_proxy=$http_proxy\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
    #   echo "Environment=\"https_proxy=$http_proxy\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
    #   echo "Environment=\"NO_PROXY=localhost,127.0.0.1,::1\"" | sudo tee -a /etc/systemd/system/docker.service.d/proxy.conf
    #   echo '{"live-restore":true}' | sudo tee -a /etc/docker/daemon.json
    #   sudo systemctl daemon-reload
    #   sudo systemctl restart docker

    # # docker commands now work "docker pull" etc.
    # sudo docker pull bkimminich/juice-shop

    # # docker compose project from github
    # COURSE_DIR_PATH=/home/pslearner/os-analysis-with-wazuh
    # git -c http.proxy=$http_proxy clone https://github.com/ps-interactive/lab_os_anlaysis_wazuh.git $COURSE_DIR_PATH
    # # Update permissions because user data script runs as root
    # chown -R pslearner:pslearner $COURSE_DIR_PATH
    # cd $COURSE_DIR_PATH
    # sudo docker-compose up -d &

    # # END FIRST BOOT CYCLE. START SECOND BOOT CYCLE.
    # rcount_inc
    # sudo reboot
    # elif [ $r -eq 1 ]; then

    # # END SECOND BOOT CYCLE. START THIRD BOOT CYCLE.
    # rcount_inc
    # sudo reboot
    # elif [ $r -eq 2 ]; then

    ##############################################
    ########## END CONTENT AUTHORING #############
    ##############################################

    ##############################################
    ########## Pluralsight Editing Only ##########
    ##############################################
    sudo /home/ubuntu/springtail.elf -clean
    sudo rm -f /home/ubuntu/springtail.elf

    rm "/psorceri/INITIALIZING"
    touch "/psorceri/SYSTEM COMPLETE"

    # End message for PS DO NOT EDIT
    echo "Happy Hunting">> /home/pslearner/peaceinourtime
fi